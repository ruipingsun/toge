#! /bin/ksh


#
# Read configuration info
#
. ./run_env_parameter

case $1 in
        "p" )
	echo "p" 
	total_time=$3
	total_thread=$4 
	run_name=$2
	report_file=$PWD/report/restbench-put.$2
	echo $run_name 
	nohup  ./rest-bench  --seconds ${total_time}  --run-name  ${run_name} --bucket=${RESTBENCH_BUCKET} --no-cleanup  --block-size=${RESTBENCH_BSIZE}   -t ${total_thread}  --api-host=${GW_IP_PORT}  --access-key=${GW_ACC_KEY}  --secret=${GW_SEC_KEY}    write     > ${report_file}  2>&1 &

        ;;
        "g" )
	echo "g" 
	total_time=$3
	total_thread=$4 
	run_name=$2
	report_file=$PWD/report/restbench-get.$2
	echo $run_name 
	nohup  ./rest-bench  --seconds ${total_time}  --run-name  ${run_name} --bucket=${RESTBENCH_BUCKET} --no-cleanup  --block-size=${RESTBENCH_BSIZE}   -t ${total_thread}  --api-host=${GW_IP_PORT}  --access-key=${GW_ACC_KEY}  --secret=${GW_SEC_KEY}    seq    > ${report_file}  2>&1 &
        ;;
        "c" )
	echo "c" 
	run_name=$2
	report_file=$PWD/report/restbench-clean.$2
	echo $run_name 
	nohup  ./rest-bench  --run-name  ${run_name} --bucket=${RESTBENCH_BUCKET} --api-host=${GW_IP_PORT}  --access-key=${GW_ACC_KEY}  --secret=${GW_SEC_KEY}    cleanup    > ${report_file}  2>&1 &

        ;;
        "m" )
	echo "m" 
	echo "=======PUT==============" 
	report_file=$PWD/report/restbench-put.$2
	grep -i "Total time run" $report_file 
	grep -i "Total writes made" $report_file 
	grep -i Latency $report_file 
	echo "=======GET==============" 
	report_file=$PWD/report/restbench-get.$2
	grep -i "Total time run" $report_file 
	grep -i "Total reads made" $report_file 
	grep -i Latency $report_file 
        ;;
        "k" )
	echo "k" 
	ps -ef | grep "rest-bench"  |  awk '{print "kill -9 " $2}' > a
	sudo sh ./a
        ;;
esac
