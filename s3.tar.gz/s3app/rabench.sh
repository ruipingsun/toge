#! /bin/ksh


#
# Read configuration info
#
. ./run_env_parameter

sudo pwd 
case $1 in
        "p" )
	echo "p" 
	total_time=$3
	total_thread=$4 
	run_name=`hostname -s`"-"$2"-" 
	report_file=$PWD/report/rabench-put.$2
	echo $run_name 
	nohup  sudo rados bench ${total_time}  write -t ${total_thread}  -p ${BENCH_POOL}  -b ${BENCH_BSIZE}   --no-cleanup --run-name ${run_name}    > ${report_file}  2>&1 &
        ;;
        "g" )
	echo "g" 
	total_time=$3
	total_thread=$4 
	run_name=`hostname -s`"-"$2"-" 
	report_file=$PWD/report/rabench-get.$2
	echo $run_name 
	nohup  sudo rados bench ${total_time}  seq  -t ${total_thread}  -p ${BENCH_POOL}  -b ${BENCH_BSIZE}   --no-cleanup --run-name ${run_name}    > ${report_file}  2>&1 &
        ;;
        "c" )
	echo "c" 
	run_name=`hostname -s`"-"$2"-" 
	report_file=$PWD/report/rabench-clean.$2
	echo $run_name 
	nohup  sudo rados cleanup   -p ${BENCH_POOL}  --run-name ${run_name}    > ${report_file}  2>&1 &
        ;;
        "m" )
	echo "m" 
	echo "=======PUT==============" 
	report_file=$PWD/report/rabench-put.$2
	grep -i Latency $report_file 
	echo "=======GET==============" 
	report_file=$PWD/report/rabench-get.$2
	grep -i Latency $report_file 
        ;;
        "k" )
	echo "k" 
	ps -ef | grep "bench" | grep "rados"  |  awk '{print "kill -9 " $2}' > a
	sudo sh ./a
        ;;
esac
