#! /bin/ksh

report_file=$PWD/report/s3curl-report.`date +%m%d%H%M`
error_code=0

#
# Read configuration info
#

. ./run_env_parameter

#
#clear report file
#

echo "===================================================" > $report_file
date  >>  $report_file




rm myfile
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --createBucket     -- -v http://$GW_IP_PORT/ruiping_bucket3/
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --put /etc/passwd  -- -v http://$GW_IP_PORT/ruiping_bucket3/testfile_1
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --                    -v http://$GW_IP_PORT/ruiping_bucket3/testfile_1
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --                    -v http://$GW_IP_PORT/ruiping_bucket3/testfile_1 -o myfile
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --delete --           -v http://$GW_IP_PORT/ruiping_bucket3/testfile_1
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --                    -v http://$GW_IP_PORT/ruiping_bucket3/
ys3curl --id $S3CURL_ID --key $S3CURL_KEY --delete --           -v http://$GW_IP_PORT/ruiping_bucket3/
wc -l myfile

