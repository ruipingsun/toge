#!/home/y/bin64/python 

import time, sys, sqlite3, os

testmethod = sys.argv[1] # only 'read' or 'write'
timestr = sys.argv[2] # time string

dbfile = "./test_log/" + testmethod + "test_" + timestr + ".db"
if not os.path.isfile(dbfile):
    print("[ERR] db file not exists: %s\n" % dbfile)
    sys.exit()

sqliteconn = sqlite3.connect(dbfile, check_same_thread = False, timeout = 10, isolation_level = "IMMEDIATE")
cursor = sqliteconn.cursor()

if testmethod == "write":
    cmd = "SELECT * FROM perftest where size != '7.2m' ORDER BY latency"
elif testmethod == "read":
    cmd = "SELECT * FROM perftest where size != '7.2M' ORDER BY latency"
else:
    print("[ERR] test method not supported: %s\n" % testmethod)

dbresult = []
try:
    for i in cursor.execute(cmd):
        dbresult.append(i)
except Exception, e:
    print("[ERR] sqlite error: %s\n" % e)

totallat = 0
ok = 0
err = 0
for i in dbresult:
    if i[2] == 1:
        ok = ok + 1
        totallat = totallat + i[3]
    else:
        err = err + 1

if ok == 0:
    print("[WRN] very rare case to reach here: %s" % cmd)
    sys.exit()

dbresult = filter(lambda x: x[2] == 1, dbresult)
avglat = totallat / ok
minlat = dbresult[0][3]
maxlat = dbresult[-1][3]
totallen = len(dbresult)
per10lat = dbresult[int(round(totallen * 0.1)) - 1][3]
per20lat = dbresult[int(round(totallen * 0.2)) - 1][3]
per30lat = dbresult[int(round(totallen * 0.3)) - 1][3]
per40lat = dbresult[int(round(totallen * 0.4)) - 1][3]
per50lat = dbresult[int(round(totallen * 0.5)) - 1][3]
per60lat = dbresult[int(round(totallen * 0.6)) - 1][3]
per70lat = dbresult[int(round(totallen * 0.7)) - 1][3]
per80lat = dbresult[int(round(totallen * 0.8)) - 1][3]
per90lat = dbresult[int(round(totallen * 0.9)) - 1][3]
per99lat = dbresult[int(round(totallen * 0.99)) - 1][3]
per999lat = dbresult[int(round(totallen * 0.999)) - 1][3]
per9999lat = dbresult[int(round(totallen * 0.9999)) - 1][3]

print("%10.10s %9.9s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s" % ('Ok', 'Err', 'Avg', 'Min', 'Max', '10%', '20%', '30%', '40%', '50%', '60%', '70%', '80%', '90%', '99%', '99.9%', '99.99%'))
print("%10.10s %9.9s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s" % (str(ok), str(err), str(avglat), str(minlat), str(maxlat), str(per10lat), str(per20lat), str(per30lat), str(per40lat), str(per50lat), str(per60lat), str(per70lat), str(per80lat), str(per90lat), str(per99lat), str(per999lat), str(per9999lat)))

