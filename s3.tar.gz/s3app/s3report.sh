# !/bin/ksh 

report_dir=$1 

rm -rf $report_dir
mkdir  $report_dir 

cp  w.out $report_dir 
cp  r.out $report_dir 

for i in  1.1M 1.4M 1.7M 136K 184K 2.1M 2.4M 2.8M 266K 3.3M 3.9M 4.6M 406K 5.6M 593K 59K 7.2M 822K 99K  ; do 
echo $i  
echo $i  > $report_dir/${i}_w
grep $i  $report_dir/w.out > tmpdata 
printf  "%-17s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s\n"  "  max_range" "slot(min)" "obj" "err" "avgmin" "avgavg" "avg80" "avg90" "avg95" "avg99" "avg100" "max"  "cliff1" "cliff2" "c1-per" "c2-per"  >> $report_dir/${i}_w 
awk -v lowlim=0   	-v uplim=300000 -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_w
awk -v lowlim=0  	-v uplim=1000   -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_w
awk -v lowlim=1000  	-v uplim=2000   -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_w
awk -v lowlim=2000  	-v uplim=5000   -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_w
awk -v lowlim=5000  	-v uplim=20000  -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_w
awk -v lowlim=20000  	-v uplim=300000  -v cliff1=2000 -v cliff2=5000    -f s3loadreport.awk tmpdata  >> $report_dir/${i}_w
done 


for i in  1.1M 1.4M 1.8M 136K 184K 2.1M 2.5M 2.9M 266K 3.4M 4.0M 4.7M 406K 5.7M 593K 59K 7.2M 822K 99K ; do 
echo $i  
echo $i  > $report_dir/${i}_r
grep $i  $report_dir/r.out > tmpdata 
printf  "%-17s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s %-8s\n"  "  max_range" "slot(min)" "obj" "err" "avgmin" "avgavg" "avg80" "avg90" "avg95" "avg99" "avg100" "max"  "cliff1" "cliff2" "c1-per" "c2-per"  >> $report_dir/${i}_r 
awk -v lowlim=0   	-v uplim=300000 -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_r
awk -v lowlim=0  	-v uplim=1000   -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_r
awk -v lowlim=1000  	-v uplim=2000   -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_r
awk -v lowlim=2000  	-v uplim=5000   -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_r
awk -v lowlim=5000  	-v uplim=20000  -v cliff1=2000 -v cliff2=5000     -f s3loadreport.awk tmpdata  >> $report_dir/${i}_r
awk -v lowlim=20000  	-v uplim=300000  -v cliff1=2000 -v cliff2=5000    -f s3loadreport.awk tmpdata  >> $report_dir/${i}_r
done 


exit 0 

