#!/usr/local/bin/python

from concurrent import futures
import time, sys, threading, random, sqlite3, multiprocessing
import socket, re, datetime, signal, os, hashlib, argparse, Queue
import boto, ConfigParser, math
import boto.s3.connection

def getopt_and_init():
    parser = argparse.ArgumentParser()
    parser.add_argument('--access_key', action="store", dest="access_key", help="Set S3 access key", required=True)
    parser.add_argument('--secret_key', action="store", dest="secret_key", help="Set S3 secret key", required=True)
    parser.add_argument('--gw_server', action="store", dest="gw_server", help="Set rados gateway hostname", required=True)
    parser.add_argument('--bucket_prefix', action="store", dest="bucket_prefix", help="Set bucket prefix", required=True)
    parser.add_argument('--bucket_num_range', action="store", dest="bucket_range", help="Set bucket num range, e.g, 1...100", required=True)
    parser.add_argument('--bucket_create', action="store", dest="bucket_create", help="(Optional) Flag to create bucket; default value is False", default=False, type=bool)
    parser.add_argument('--max_object_num', action="store", dest="max_object_num", help="(Optional) Set max object number; default value is 100000000", default=100000000, type=int)
    parser.add_argument('--rps', action="store", dest="rps", help="(Optional) Set rps, default value is 10", default=10, type=int)
    parser.add_argument('--port', action="store", dest="port", help="(Optional) Set GW port, default value is 4080", default=4080, type=int)
    parser.add_argument('--single_size', action="store", dest="single_size", help="(Optional) Set singe test file size from ./file_set/testfile_<size>, default value is ALL", default='ALL', type=str)
    parser.add_argument('--report_interval', action="store", dest="report_interval", help="(Optional) Set report interval (seconds), default value is 100", default=100, type=int)
    parser.add_argument('--timeout', action="store", dest="timeout", help="(Optional & Experimental) Set request timeout (seconds), default value is 20", default='20', type=str)
    
    args = parser.parse_args()
    boto.config.add_section('Boto')
    boto.config.set('Boto', 'http_socket_timeout', args.timeout)
    boto.config.set('Boto', 'num_retries', '0')
    conf_dict = {}
    conn = boto.connect_s3(
            aws_access_key_id = args.access_key,
            aws_secret_access_key = args.secret_key,
            host = args.gw_server,
            is_secure=False, # uncommmnt if you are not using ssl
            port = args.port,
            calling_format = boto.s3.connection.OrdinaryCallingFormat(),
            )
    
    conf_dict['Conn'] = conn
    conf_dict['Bucket_Prefix'] = args.bucket_prefix
    conf_dict['Bucket_Startnum'] = args.bucket_range.split("...")[0]
    conf_dict['Bucket_Endnum'] = args.bucket_range.split("...")[1]
    if ((not conf_dict['Bucket_Startnum'].isdigit()) or (not conf_dict['Bucket_Endnum'].isdigit())):
       print("[ERR] Option --bucket_range is invalid? %s" % args.bucket_range)
       sys.exit()
    
    if (args.rps <= 0):
	      print("[ERR] Option --rps <= 0? %d" % args.rps)
	      sys.exit()

    conf_dict['Rps'] = args.rps
    conf_dict['Object_Set_Cnt'] = args.max_object_num
    conf_dict['Host_Name'] = socket.gethostname()
    conf_dict['Time'] = time.time()
    conf_dict['Object_Idx'] = 0
    conf_dict['Bool_Create_Bucket'] = args.bucket_create
    conf_dict['Single_Size'] = args.single_size
    conf_dict['Report_Interval'] = args.report_interval
    
    return conf_dict


def create_bucket():
    global Conf_Dict
    Conf_Dict['Bucket_Object'] = {}
    start = int(Conf_Dict['Bucket_Startnum'])
    end = int(Conf_Dict['Bucket_Endnum'])
    maxworkers = Conf_Dict['Rps']
    while (start <= end):
        with futures.ThreadPoolExecutor(max_workers=maxworkers) as executor:
            for n in range(start, start + 10):
                bucketname = Conf_Dict['Bucket_Prefix'] + str(n)
                executor.submit(__createbucket, Conf_Dict['Bucket_Prefix'], str(n))
        start += 10


def __createbucket(prefix, id):
    global Conf_Dict
    bucketname = prefix + id
    try:
        bucket = Conf_Dict['Conn'].get_bucket(bucketname, validate=Conf_Dict['Bool_Create_Bucket'])
    except Exception, e:
        try:
            bucket = Conf_Dict['Conn'].create_bucket(bucketname)
        except Exception, e:
            print("[ERR] Failed to create bucket %s: %s" % (bucketname, e))
            Conf_Dict['Exit_Flag'] = True

    Conf_Dict['Bucket_Object'][id] = bucket


class SqliteWriter(threading.Thread):
    def __init__(self, queue, sqlitedb, table):
        threading.Thread.__init__(self)
        self.queue = queue
        self.sqliteconn = sqlite3.connect(sqlitedb, check_same_thread = False, timeout = 10, isolation_level = "IMMEDIATE")
        cursor = self.sqliteconn.cursor()
        cursor.execute("PRAGMA synchronous = 0")
        self.exitflag = False
        self.table = table

    def run(self):
        time_out = 1
        while not self.exitflag:
            try:
                tstamp, size, status, lat = self.queue.get(timeout=time_out)
            except Queue.Empty:
                continue

            try:
                cursor = self.sqliteconn.cursor()
                cmd = "INSERT INTO " + self.table + " VALUES "
                cmd += "(" + str(tstamp) + ",'" + size + "'," + str(status) + "," + str(lat) + ")"
                cursor.execute(cmd)
                self.sqliteconn.commit()
            except Exception, e:
                print("[ERR] sqlite error at %s->%s : %s" % (self.__class__.__name__, sys._getframe().f_code.co_name, e))

    def exit(self):
        self.exitflag = True
                

class SqliteReader(threading.Thread):
    def __init__(self, logfile, interval, sqlitedb, table):
        threading.Thread.__init__(self)
        self.logfile = logfile
        self.sqliteconn = sqlite3.connect(sqlitedb, check_same_thread = False, timeout = 10, isolation_level = "IMMEDIATE")
        self.exitflag = False
        self.table = table
        self.interval = interval
        self.count = 0
        self.objcreated = 0
        self.event = threading.Event()

    def run(self):
        curtime = datetime.datetime.now() - datetime.datetime(1970,1,1)
        starttime = (curtime.days * 24 * 60 * 60 + curtime.seconds) * 1000 + curtime.microseconds / 1000
        self.__format_ouput(0)
        while not self.exitflag:
            #time.sleep(self.interval)
            if (self.event.wait(self.interval)):
                continue
            endtime = starttime + self.interval * 1000
            self.count = self.count + 1
            cursor = self.sqliteconn.cursor()
            sizelist = self.__sqlite_select_filesize(cursor, starttime, endtime)
            for s in sizelist:
                ok, err, avglat = self.__sqlite_select_status_avglat_per_size(cursor, s, starttime, endtime)
                minlat, maxlat, per80lat, per90lat, per95lat, per99lat = self.__sqlite_select_min_max_lat_per_size(cursor, s, starttime, endtime)
                self.__format_ouput(self.count, s, ok, err, avglat, minlat, maxlat, per80lat, per90lat, per95lat, per99lat)
            starttime = endtime

        fh = open(self.logfile, "a")
        fh.write("\n")
        fh.write("Total Object: %s" % str(self.objcreated))
        fh.write("\n")
        fh.close()

    def __format_ouput(self, count, size=None, ok=None, err=None, avglat=None, minlat=None, maxlat=None, per80lat=None, per90lat=None, per95lat=None, per99lat=None):
        fh = open(self.logfile, "a")
        if count == 0:
            print("%9.9s %5.5s %10.10s %9.9s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s" % ('Seq', 'Size', 'Ok', 'Err', 'Avg', 'Min', 'Max', '80%', '90%', '95%', '99%'))
            fh.write("%9.9s %5.5s %10.10s %9.9s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s" % ('Seq', 'Size', 'Ok', 'Err', 'Avg', 'Min', 'Max', '80%', '90%', '95%', '99%'))
            fh.write("\n")
        else:
            seq = self.interval * self.count
            print("%9.9s %5.5s %10.10s %9.9s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s" % (str(seq), size.upper(), str(ok), str(err), str(avglat), str(minlat), str(maxlat), str(per80lat), str(per90lat), str(per95lat), str(per99lat)))
            fh.write("%9.9s %5.5s %10.10s %9.9s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s %6.6s" % (str(seq), size.upper(), str(ok), str(err), str(avglat), str(minlat), str(maxlat), str(per80lat), str(per90lat), str(per95lat), str(per99lat)))
            fh.write("\n")
        fh.close()

    def __sqlite_select_status_avglat_per_size(self, cursor, size, starttime, endtime):
        cmd = "SELECT * FROM " + self.table
        cmd += " where date <= " + str(endtime) + " and date > " + str(starttime) + " and size = '" + size + "'"
        cmd += " ORDER BY latency"
        dbresult = []
        try:
            for i in cursor.execute(cmd):
                dbresult.append(i)
        except Exception, e:
            print("[ERR] sqlite error at %s->%s : %s" % (self.__class__.__name__, sys._getframe().f_code.co_name, e))

        totallat = 0
        ok = 0
        err = 0
        for i in dbresult:
            if i[2] == 1:
                ok = ok + 1
                totallat = totallat + i[3]
                self.objcreated = self.objcreated + 1
            else:
                err = err + 1

        if ok == 0:
            #print("[WRN] very rare case to reach here: %s" % cmd)
            return [ok, err, 0]
        return [ok, err, totallat / ok]

    def __sqlite_select_min_max_lat_per_size(self, cursor, size, starttime, endtime):
        cmd = "SELECT * FROM " + self.table
        cmd += " where date <= " + str(endtime) + " and date > " + str(starttime) + " and size = '" + size + "'"
        cmd += " and latency != -1 ORDER BY latency"
        dbresult = []
        try:
            for i in cursor.execute(cmd):
                dbresult.append(i)
        except Exception, e:
            print("[ERR] sqlite error at %s->%s : %s" % (self.__class__.__name__, sys._getframe().f_code.co_name, e))
        
        if not dbresult:
            return [0, 0, 0, 0, 0, 0]
        minlat = dbresult[0][3]
        maxlat = dbresult[-1][3]

        totallen = len(dbresult)
        per80lat =dbresult[int(round(totallen * 0.8)) - 1][3]
        per90lat =dbresult[int(round(totallen * 0.9)) - 1][3]
        per95lat =dbresult[int(round(totallen * 0.95)) - 1][3]
        per99lat =dbresult[int(round(totallen * 0.99)) - 1][3]
        return [minlat, maxlat, per80lat, per90lat, per95lat, per99lat]

    def __sqlite_select_filesize(self, cursor, starttime, endtime):
        cmd = "SELECT DISTINCT size FROM " + self.table
        cmd += " where date <= " + str(endtime) + " and date > " + str(starttime)
        dbresult = []
        try:
            for i in cursor.execute(cmd):
                dbresult.append(i[0])
        except Exception, e:
            print("[ERR] sqlite error at %s->%s : %s" % (self.__class__.__name__, sys._getframe().f_code.co_name, e))

        return dbresult

    def exit(self):
        self.exitflag = True
        self.event.set()
        

def putOps(arg):
    global Conf_Dict
    obj_key_base = str(Conf_Dict['Time']) + str(arg['obj_idx'])
    obj_key_hash = hashlib.new("md5", obj_key_base).hexdigest()
    obj_key = Conf_Dict['Host_Name'] + '_' + obj_key_hash 
    upload_file = "./file_set/testfile_" + arg['file_size']
    bucket_idx = int(Conf_Dict['Bucket_Startnum']) 
    bucket_idx += int(arg['obj_idx']) % (int(Conf_Dict['Bucket_Endnum']) - int(Conf_Dict['Bucket_Startnum']) + 1)
    bucket = Conf_Dict['Bucket_Object'][str(bucket_idx)]
    
    try:
        key = bucket.new_key(obj_key)
        d1 = datetime.datetime.now()
        key.set_contents_from_filename(upload_file)
        d2 = datetime.datetime.now()
        dt1 = d2 - d1
        lat = (dt1.days * 24 * 60 * 60 + dt1.seconds) * 1000 + dt1.microseconds / 1000
        dt2 = d2 - datetime.datetime(1970,1,1)
        cur = (dt2.days * 24 * 60 * 60 + dt2.seconds) * 1000 + dt2.microseconds / 1000
    except Exception, e:
        #print("[ERR]: e=%s, bucket id=%s" % (e, str(bucket_idx)))
        dt2 = datetime.datetime.now() - datetime.datetime(1970,1,1)
        cur = (dt2.days * 24 * 60 * 60 + dt2.seconds) * 1000 + dt2.microseconds / 1000
        status = 0
        lat = -1
    else:
        status = 1

    #print("thread done... %s" % (arg['file_size']))
    return [cur, arg['file_size'], status, lat]
         

def signalHandler(signalnum, frame):
    global Conf_Dict
    #print("exiting now...")
    #os.killpg(0, signal.SIGTERM)
    #sys.exit();
    Conf_Dict['Exit_Flag'] = True


def request_process(currentrps, proclock):
    global Conf_Dict
    procname = multiprocessing.current_process().name
    request_scheduler(currentrps, proclock, procname)

    while not Conf_Dict['Exit_Flag']:
        time.sleep(5)


def request_scheduler(currentrps, proclock, procname):
    global Conf_Dict
    t = threading.Timer(1.0, request_scheduler, [currentrps, proclock, procname])
    t.start()
    
    if Conf_Dict['Exit_Flag']:
        t.cancel()
        return

    put_args = []
    proclock.acquire()
    if ((Conf_Dict['Object_Set_Cnt'] != 0) and (Conf_Dict['Object_Idx'] > Conf_Dict['Object_Set_Cnt'])):
        Conf_Dict['Object_Idx'] = 0

    for i in range(currentrps):
        file_size = random.choice(Conf_Dict['Distri_Tags'])
        put_args.append({'file_size':file_size, 'obj_idx':Conf_Dict['Object_Idx']})
        Conf_Dict['Object_Idx'] += 1
    proclock.release()

    with futures.ThreadPoolExecutor(max_workers=currentrps) as executor:
        for res in executor.map(putOps, put_args):
            Conf_Dict['Queue'].put(res)


def request_process_init():
    global Conf_Dict
    rps_per_process = 20
    process_num = Conf_Dict['Rps'] / rps_per_process + (1 if Conf_Dict['Rps'] % rps_per_process != 0 else 0)
    requestp_lock = multiprocessing.Lock()
    requestp = []
    for i in range(process_num):
        if (rps_per_process * (i + 1) <= Conf_Dict['Rps']):
            rp = multiprocessing.Process(name='request_process_' + str(i), target=request_process, args=(rps_per_process, requestp_lock,))
        else:
            rest_rps = Conf_Dict['Rps'] - rps_per_process * i
            rp = multiprocessing.Process(name='request_process_' + str(i), target=request_process, args=(rest_rps, requestp_lock,))
        rp.daemon = True
        requestp.append(rp)

    for p in requestp:
        p.start()
    return requestp


def result_process_init(queue, logfile):
    global Conf_Dict
    fh = open(logfile, 'w')
    fh.write('Start Time: ' + str(Conf_Dict['Time']))
    fh.write('\n' + '\n')
    fh.close()

    resultp = multiprocessing.Process(name='result_process', target=result_process, args=(queue, logfile,))
    resultp.daemon = True
    resultp.start()
    return resultp


def result_process(queue, logfile):
    global Conf_Dict
    sqlitedb = './test_log/writetest_' + str(Conf_Dict['Time']) + '.db'
    table = "perftest"
    cmd = "CREATE TABLE " + table + " (date int64, size text, status int, latency int)"
    try:
        sqliteconn = sqlite3.connect(sqlitedb, check_same_thread = False, timeout = 10, isolation_level = "IMMEDIATE")
        c = sqliteconn.cursor()
        c.execute(cmd)
        sqliteconn.commit()
        sqliteconn.close()
    except Exception, e:
        print("[ERR] sqlite error at %s->%s : %s" % (self.__class__.__name__, sys._getframe().f_code.co_name, e))
        Conf_Dict['Exit_Flag'] = True
        return

    sqlitewriter = SqliteWriter(queue, sqlitedb, table)
    sqlitewriter.setDaemon(True)
    sqlitewriter.start()

    sqlitereader = SqliteReader(logfile, Conf_Dict['Report_Interval'], sqlitedb, table)
    sqlitereader.setDaemon(True)
    sqlitereader.start()

    while not Conf_Dict['Exit_Flag']:
        time.sleep(5)

    sqlitewriter.exit()
    sqlitereader.exit()
    while sqlitewriter.isAlive() or sqlitereader.isAlive():
        time.sleep(5)
    sqliteconn.close()


def generate_random_tagstr_distribution(tags):
    if len(tags) == 0:
        print("[ERR] File size distribution not found")
        sys.exit()
    distri_tags = []
    for (k,v) in tags.items():
        for i in range(0,v):
            distri_tags.append(k)
    return distri_tags


def get_size_distribution_setting():
    districonf = ConfigParser.ConfigParser()
    try:
        districonf.read("./file_set/size_distribution.conf")
    except ConfigParser.Error, e:
        print("[ERR] Failed to read distribution conf file")
        sys.exit()

    disdict = {}
    for k, v in districonf.items("size_distribution"):
        if not os.path.exists("./file_set/" + k):
            print("[WRN] Not found test file: " + k)
            continue

        size = k.split("_")[1]
        disdict[size] = int(math.ceil(float(v)))
    return disdict


if __name__ == '__main__':
    if sys.version_info < (2, 7):
        sys.exit("Require python 2.7 or newer!: %s" % sys.version_info)

    global Conf_Dict 
    Conf_Dict = getopt_and_init()
    Conf_Dict['Exit_Flag'] = False
    
    # signal handler
    signal.signal(signal.SIGINT, signalHandler)
    signal.signal(signal.SIGTERM, signalHandler)
    signal.signal(signal.SIGALRM, signalHandler)

    # init queue
    queue = multiprocessing.Queue()
    Conf_Dict['Queue'] = queue

    if Conf_Dict['Single_Size'] == 'ALL':
        tagdict = get_size_distribution_setting()
    else:
        tagdict = {Conf_Dict['Single_Size']:1} 
    Conf_Dict['Distri_Tags'] = generate_random_tagstr_distribution(tagdict)

    # log file and time
    cur_time = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
    logfile = "./test_log/raw_test_result_" + cur_time + '.log'
    print("\nLog file: %s\n" % logfile)
    
    # deamon process for writing result to file 
    resultp = result_process_init(queue, logfile)

    # request sched and initiator
    create_bucket()
    requestp = request_process_init()
    for p in requestp:
        p.join()
    resultp.join()
    print("\nCheck report in log file: %s\n" % logfile)
    
