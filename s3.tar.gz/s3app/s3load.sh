#! /bin/ksh

report_file=$PWD/report/s3load-report.`date +%m%d%H%M`
error_code=0

#
# Read configuration info
#

. ../s3app/run_env_parameter

#
#clear report file
#

echo "===================================================" > $report_file
date  >>  $report_file



case $1 in
        'i' )
	echo "i" 
	  ./put_load_test_v4.py --access_key ${GW_ACC_KEY} --secret_key ${GW_SEC_KEY}   --gw_server  ${GW_IP}  --bucket_prefix ruipingtestbucket${LOAD_SEQ}"_" --bucket_num_range 1...${LOAD_BUCKET_NUM_RANGE} --rps $2 --port $GW_PORT --report_interval ${LOAD_REPORT_INT}     --bucket_create True
        ;;
        "p" )
	echo "p" 
	nohup   ./put_load_test_v4.py --access_key ${GW_ACC_KEY} --secret_key ${GW_SEC_KEY}   --gw_server  ${GW_IP}  --bucket_prefix ruipingtestbucket${LOAD_SEQ}"_" --bucket_num_range 1...${LOAD_BUCKET_NUM_RANGE} --rps $2 --port $GW_PORT   --report_interval ${LOAD_REPORT_INT}      > w.out 2>&1 &
        ;;
        "g" )
	echo "g" 
	obj_num=` grep Star test_log/$3 | awk '{print \$3}'`
	 echo $obj_num 
	nohup   ./get_load_test_v4.py --access_key ${GW_ACC_KEY} --secret_key ${GW_SEC_KEY}   --gw_server  ${GW_IP}  --bucket_prefix ruipingtestbucket${LOAD_SEQ}"_" --bucket_num_range 1...${LOAD_BUCKET_NUM_RANGE} --rps $2 --port $GW_PORT   --report_interval ${LOAD_REPORT_INT}  --object_time_string $obj_num --max_object_num $4 > r.out 2>&1  &      
        ;;
	 "k" )
        echo "k"
	ps -ef | grep "load_test" | awk '{print "kill -9 " $2}' > a
        sh ./a
        ;;
	 "m" )
        echo "m"
	echo "=======PUT=============="
	grep 2.4M w.out
	grep 2.4M w.out  | awk -f s3load.awk
	echo "=======GET=============="
	grep 2.5M r.out
	grep 2.5M r.out  | awk -f s3load.awk
        ;;
esac
